package com.emp.dao;

import java.util.List;

import com.emp.model.Emp;




public interface IEmpDao {

	void save(Emp emp);
	void update(Emp emp);

	void delete(long id);
}
