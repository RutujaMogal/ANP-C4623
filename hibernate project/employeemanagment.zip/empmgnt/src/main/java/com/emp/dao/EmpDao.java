package com.emp.dao;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import com.emp.model.Emp;


import org.hibernate.Session;
import org.hibernate.Transaction;




import lombok.extern.slf4j.*;



public class EmpDao {

	private static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
    
	  public void save(Emp emp) {
	    Transaction tx = null;
	    try (Session session = sessionFactory.openSession()) 
	    {
	      tx = session.beginTransaction();
	      session.save(emp);
	      tx.commit();
	    } catch (Exception e) {
	      if (tx != null) {
	        tx.rollback();
	      }
	      e.printStackTrace();
	    }
	  }
	  public void update(Emp emp) 
		{
	        Transaction tx = null;
	        try (Session session = sessionFactory.openSession()) 
	        {
	            // start the transaction
	            tx = session.beginTransaction();

	            // save student object
	            session.saveOrUpdate(emp);

	            // commit the transaction
	            tx.commit();
	        } 
	        catch (Exception e)
	        {
	            if (tx != null)
	            {
	                tx.rollback();
	            }
	        }
	    }
	  public void delete(Emp id) {
	        Transaction tx = null;
	        Emp emp = null;
	        try (Session session = sessionFactory.openSession())
	        {
	            // start the transaction
	            tx = session.beginTransaction();
	           
	            // get student object
	            session.delete(id);
	            //student = session.load(Student.class, id);
	            // commit the transaction
	            tx.commit();
	        } catch (Exception e) {
	            if (tx != null) {
	               // transaction.rollback();
	            }
	        }
	  }

	  
}
