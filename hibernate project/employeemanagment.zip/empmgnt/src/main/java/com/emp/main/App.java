package com.emp.main;
import org.hibernate.cfg.Configuration;
import com.emp.model.Emp;
import com.emp.dao.*;
public class App {

	public static void main(String[]args) {
	EmpDao empdao=new EmpDao();
	Emp emp=new Emp(1,"Rutuja","Gavale@gmail.com",30000);
    Emp emp1=new  Emp(2, "Pooja","Patil@gmail.com",4300);
    Emp emp2=new  Emp(3, "sai","Patil@gmail.com",5500);
    empdao.save(emp);
    empdao.save(emp1);
    empdao.save(emp2);
    
    empdao.update(emp);
   empdao.delete(emp2);
	}
}
