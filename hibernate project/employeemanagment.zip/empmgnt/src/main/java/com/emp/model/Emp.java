package com.emp.model;
import lombok.*;
import javax.persistence.*;

@Entity
@Table(name = "employee")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Data
 
public class Emp {
	
	 @Id
	  @GeneratedValue(strategy = GenerationType.AUTO)
	 @Column(name = "id")
	  private int id;

	  @Column(name = "Emp_name")
	  private String Emp_name;

	  @Column(name = "Emp_email")
	  private String Emp_email;
	  
	  @Column(name = "Salary")
	  private long Salary;
	
}
