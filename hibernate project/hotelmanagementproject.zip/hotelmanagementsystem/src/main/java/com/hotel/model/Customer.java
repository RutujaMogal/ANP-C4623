package com.hotel.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity  
@Table(name = "customer")
public class Customer
{
	  @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "id")
	    private int id;

	    @Column(name = "first_name")
	    private String firstName;

	    @Column(name = "last_name")
	    private String lastName;

	    @Column(name = "mobile_number")
	    private String mobile_number;
	  

	    @Column(name = "room_number")
	    private int room_number;
	    
	    @Column(name = "payment_status")
	    private String payment_status;

	  //default constructor
		public Customer() 
		{
			
		}
	 
		//parameterized constructor
		public Customer(String firstName, String lastName, String mobile_number,int room_number,String payment_status) 
		{
			this.firstName = firstName;
			this.lastName = lastName;
			this.mobile_number=mobile_number;
			this.room_number=room_number;
			this.payment_status=payment_status;
			
		}
	    //getter and setter method

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

	
		public String getMobile_number() {
			return mobile_number;
		}

		public void setMobile_number(String mobile_number) {
			this.mobile_number = mobile_number;
		}

		public int getRoom_number() {
			return room_number;
		}

		public void setRoom_number(int room_number) {
			this.room_number = room_number;
		}

		public String getPayment_status() {
			return payment_status;
		}

		public void setPayment_status(String payment_status) {
			this.payment_status = payment_status;
		}
		
		//toString() method

		@Override
		public String toString() {
			return "Customer [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", mobile_number="
					+ mobile_number + ", room_number=" + room_number + ", payment_status=" + payment_status + "]";
		}

		
		
		  
}
