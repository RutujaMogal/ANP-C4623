package com.hotel;

import java.util.List;

import com.hotel.dao.CustomerDao;
import com.hotel.model.Customer;

/**4
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	CustomerDao customerDao = new  CustomerDao();

        // test saveCustomer
    	 Customer customer=new  Customer("Rutuja","Gavale","7820916201",1,"Done");
        Customer  customer1 =new  Customer("Pooja","Patil","9834728282",2,"Done");
        Customer  customer2 =new  Customer("Sai","Patil","9563728910",3,"Done");
        Customer  customer3 =new  Customer("Sakshi","Gavale","7836674838",4,"Done");
        //passing value in parameterized constructor
        customerDao.saveCustomer( customer);
        customerDao.saveCustomer( customer1);
        customerDao.saveCustomer( customer2);
        customerDao.saveCustomer( customer3);
        
        // test updateCustomer
        customer.setFirstName("Rutuja");
        customerDao.updateCustomer(customer);
        
     // test getCustomerById
        //Customer customer2 = customerDao.getCustomerById(student.getId());

        // test getAllStudents
        List < Customer > customers = customerDao.getAllCustomers();
        customers.forEach(Customer3 -> System.out.println(Customer3.getId()));
        // -> lambda expression left side of arrow:parameter ; right:value
 
        
        // test deleteStudent
        customerDao.deleteCustomer(3);
    }
}
