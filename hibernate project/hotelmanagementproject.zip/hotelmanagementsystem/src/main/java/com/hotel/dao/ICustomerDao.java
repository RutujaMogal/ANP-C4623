package com.hotel.dao;

import java.util.List;

import com.hotel.model.Customer;


public class ICustomerDao 
{
	 void saveCustomer(Customer customer) {
	};

	 void updateCustomer(Customer customer) {
	}

		Customer getCustomerById(long id) {
			return null;
		}

		List<Customer> getAllCustomers() {
			return null;
		}


	 void deleteCustomer(long id) {
	}
}
