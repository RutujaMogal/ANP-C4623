package com.example.main;
import org.hibernate.cfg.Configuration;
import com.example.model.User;
import com.example.dao.*;
public class App {
  public static void main(String[] args) 
  {
	 
		UserDao dao = new UserDao();	    
	    // Create a new user entity
	    User user = new User();
	    user.setName("Rutuja Gavale");
	    user.setEmail("rutuja@gmail.com");
	    dao.saveUser(user);
	    User user1 = new User();
	    user1.setName("Sakshi Patil");
	    user1.setEmail("sakshi@gmail.com");
	    dao.saveUser(user1);
	    
	   dao. updateUser(user);
	   dao.deleteUser(user1);


  }
}
